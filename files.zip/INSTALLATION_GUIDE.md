# TAPSA SJUT Platform - Complete Installation & Setup Guide

## 🎯 Complete Step-by-Step Installation

This guide will walk you through setting up the complete TAPSA SJUT backend system.

---

## 📋 Prerequisites

Before starting, ensure you have:

1. **Node.js** (v16 or higher)
   - Download: https://nodejs.org/
   - Verify: `node --version`

2. **MySQL Server** (v8.0 or higher)
   - Download: https://www.mysql.com/downloads/
   - Verify: `mysql --version`

3. **Git** (for version control)
   - Download: https://git-scm.com/

4. **Text Editor/IDE**
   - VS Code, WebStorm, or similar

5. **Postman** (for API testing - optional)
   - Download: https://www.postman.com/

---

## 🔧 Installation Steps

### Step 1: Create Project Directory

```bash
# Create and navigate to project directory
mkdir tapsa-sjut-platform
cd tapsa-sjut-platform
```

### Step 2: Initialize Node.js Project

```bash
# Copy all provided files to this directory:
# - server.js
# - package.json
# - .env.example
# - database_schema.sql
# - login.html
# - README.md
# - INSTALLATION_GUIDE.md

# Initialize git (optional but recommended)
git init
```

### Step 3: Install Node.js Dependencies

```bash
# Install all required packages
npm install

# Output should show:
# added XX packages in X.XXs
```

### Step 4: Setup MySQL Database

#### Option A: Using Command Line

```bash
# Open MySQL command line
mysql -u root -p

# Enter your MySQL password when prompted
# Then run these commands:

CREATE DATABASE tapsa_sjut_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tapsa_sjut_db;

# Copy and paste the entire database_schema.sql content
# Or use source command:

SOURCE /path/to/database_schema.sql;

# Verify tables were created
SHOW TABLES;

# Exit MySQL
EXIT;
```

#### Option B: Using MySQL Workbench

1. Open MySQL Workbench
2. Create new connection to localhost
3. Create new schema named `tapsa_sjut_db`
4. Go to File → Open SQL Script
5. Select `database_schema.sql`
6. Execute the script (Ctrl+Shift+Enter)

#### Option C: Using PhpMyAdmin

1. Open PhpMyAdmin (usually http://localhost/phpmyadmin)
2. Click "New" to create database
3. Name: `tapsa_sjut_db`
4. Collation: `utf8mb4_unicode_ci`
5. Create database
6. Click on the new database
7. Import `database_schema.sql` using Import tab

### Step 5: Configure Environment Variables

```bash
# Copy environment template
cp .env.example .env

# Edit .env file with your settings
# On Windows: notepad .env
# On Mac/Linux: nano .env

# Update these critical variables:
NODE_ENV=development
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=tapsa_sjut_db
JWT_SECRET=change_this_to_random_secret_string_at_least_32_characters

# Generate a random JWT secret:
# On Mac/Linux: openssl rand -base64 32
# On Windows PowerShell: [Convert]::ToBase64String((1..32|ForEach-Object{Get-Random -Maximum 256}))
```

### Step 6: Verify Database Connection

```bash
# Create a test connection script
cat > test-db.js << 'EOF'
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'tapsa_sjut_db'
});

pool.getConnection()
    .then(connection => {
        console.log('✓ Database connected successfully');
        connection.release();
        process.exit(0);
    })
    .catch(error => {
        console.error('✗ Database connection failed:', error.message);
        process.exit(1);
    });
EOF

# Load environment
source .env  # On Windows: set /p < .env

# Run test
node test-db.js
```

### Step 7: Start the Server

```bash
# Development mode (with auto-reload)
npm run dev

# You should see:
# ╔════════════════════════════════════════════╗
# ║   TAPSA SJUT Platform - Backend Server     ║
# ╠════════════════════════════════════════════╣
# ║ Server running on port: 5000
# ║ Environment: development
# ║ Database: tapsa_sjut_db
# ╚════════════════════════════════════════════╝
```

---

## 🧪 Testing the Setup

### Test 1: Check API Health

```bash
# Open another terminal and run:
curl http://localhost:5000/api/health

# Expected response:
# {"success":true,"message":"TAPSA SJUT API is running","version":"1.0.0"}
```

### Test 2: Test Login Endpoint

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@tapsa.com",
    "password": "Demo@123",
    "role": "Admin"
  }'

# Expected response:
# {
#   "success": true,
#   "token": "eyJhbGciOiJIUzI1NiIs...",
#   "user": {...}
# }
```

### Test 3: Test Login Page

1. Open `login.html` in your web browser
2. Use these credentials:
   - Email: `admin@tapsa.com`
   - Password: `Demo@123`
   - Role: `Admin`
3. Click "Sign In"
4. Should see success message

### Test 4: Use Postman

1. Open Postman
2. Create new collection "TAPSA SJUT API"
3. Create requests for:
   - GET /api/health
   - POST /api/auth/login
   - GET /api/users/profile
4. Set Authorization header: `Bearer {token}`

---

## 🔄 Database Backup & Restore

### Backup Database

```bash
# Create backup
mysqldump -u root -p tapsa_sjut_db > backup_$(date +%Y%m%d_%H%M%S).sql

# Or use this for full backup with all databases
mysqldump -u root -p --all-databases > full_backup_$(date +%Y%m%d_%H%M%S).sql
```

### Restore Database

```bash
# Restore from backup
mysql -u root -p tapsa_sjut_db < backup_20240115_120000.sql

# Or restore all databases
mysql -u root -p < full_backup_20240115_120000.sql
```

---

## 🔐 Security Configuration

### Change Default Credentials

```bash
# Login to MySQL as admin
mysql -u root -p

# Update admin password
UPDATE users SET password_hash = SHA2('NewSecurePassword', 256) 
WHERE registration_number = 'REG001';

# Update other test users similarly
```

### Generate Strong JWT Secret

```bash
# On Mac/Linux
openssl rand -base64 32

# On Windows PowerShell
[Convert]::ToBase64String((0..31 | ForEach-Object { [byte]$_ }))

# Copy the output and update JWT_SECRET in .env
```

### Secure .env File

```bash
# Make .env readable only by owner (Linux/Mac)
chmod 600 .env

# Add to .gitignore to prevent accidental commits
echo ".env" >> .gitignore
echo "*.log" >> .gitignore
echo "uploads/" >> .gitignore
echo "node_modules/" >> .gitignore
```

---

## 📱 Frontend Integration

### Setup Frontend

1. **Create Frontend Directory**
```bash
cd ..
mkdir tapsa-sjut-frontend
cd tapsa-sjut-frontend
```

2. **Create index.html**
```html
<!DOCTYPE html>
<html>
<head>
    <title>TAPSA SJUT Platform</title>
    <script src="app.js"></script>
</head>
<body>
    <div id="app"></div>
</body>
</html>
```

3. **Create app.js**
```javascript
const API_URL = 'http://localhost:5000/api';

class TAPSAApp {
    constructor() {
        this.token = localStorage.getItem('user_token');
    }

    async login(email, password, role) {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, role })
        });
        return await response.json();
    }

    async getProfile() {
        const response = await fetch(`${API_URL}/users/profile`, {
            headers: { 'Authorization': `Bearer ${this.token}` }
        });
        return await response.json();
    }
}

const app = new TAPSAApp();
```

4. **Start Frontend Server**
```bash
# Using Python
python -m http.server 3000

# Or using Node
npx http-server -p 3000
```

---

## 🐛 Troubleshooting

### Issue 1: MySQL Connection Error

```
Error: connect ECONNREFUSED 127.0.0.1:3306
```

**Solution:**
- Check MySQL service is running
- Windows: `net start MySQL80` (or your version)
- Mac: `mysql.server start`
- Linux: `sudo service mysql start`
- Verify connection: `mysql -u root -p`

### Issue 2: Port 5000 Already in Use

```
Error: listen EADDRINUSE: address already in use :::5000
```

**Solution:**
- Kill existing process:
  ```bash
  # On Mac/Linux
  lsof -ti:5000 | xargs kill -9
  
  # On Windows
  netstat -ano | findstr :5000
  taskkill /PID <PID> /F
  ```
- Or change PORT in .env file

### Issue 3: JWT Secret Not Set

```
Error: JWT secret is undefined
```

**Solution:**
- Ensure .env file exists
- JWT_SECRET is set to non-empty value
- Restart server after changing .env

### Issue 4: Database Tables Not Found

```
Error: Table 'tapsa_sjut_db.users' doesn't exist
```

**Solution:**
- Verify database was created: `SHOW DATABASES;`
- Verify tables exist: `USE tapsa_sjut_db; SHOW TABLES;`
- Re-run database_schema.sql if needed

### Issue 5: Permission Denied on Uploads

```
Error: EACCES: permission denied, open './uploads/...'
```

**Solution:**
```bash
# Create uploads directory
mkdir -p uploads
chmod 755 uploads

# Or change upload directory in .env
UPLOAD_DIR=/tmp/tapsa-uploads
```

---

## 📊 Database Management

### Add New Admin User

```sql
-- Generate password hash (use bcrypt in production)
INSERT INTO users (
    registration_number, email, phone_number, password_hash,
    full_name, status, role
) VALUES (
    'ADMIN002', 'newadmin@tapsa.com', '255754000000',
    '$2b$10$hash_here', 'New Admin', 'Active', 'Admin'
);
```

### View All Users

```sql
SELECT id, registration_number, email, full_name, role, status FROM users;
```

### Reset Member Password

```sql
-- Note: Use bcrypt hash in production
UPDATE users SET password_hash = '$2b$10$new_hash' 
WHERE registration_number = 'REG001';
```

### Check Database Statistics

```sql
-- Total members
SELECT COUNT(*) as total_members FROM users WHERE role = 'Member';

-- Active members
SELECT COUNT(*) as active_members FROM users WHERE status = 'Active';

-- Pending fees
SELECT COUNT(*) as pending_fees FROM membership_fees WHERE status = 'Pending';

-- Recent announcements
SELECT COUNT(*) as total_announcements FROM announcements WHERE is_published = TRUE;
```

---

## 🚀 Production Deployment

### Pre-Deployment Checklist

- [ ] Change all default passwords
- [ ] Update JWT_SECRET to strong random value
- [ ] Set NODE_ENV=production in .env
- [ ] Configure database backups
- [ ] Set up SSL/HTTPS certificates
- [ ] Configure email SMTP settings
- [ ] Enable audit logging
- [ ] Test all API endpoints
- [ ] Set up monitoring and alerts
- [ ] Configure firewall rules
- [ ] Document API endpoints

### Production .env Example

```env
NODE_ENV=production
PORT=5000
DB_HOST=prod-db.example.com
DB_USER=produser
DB_PASSWORD=StrongSecurePassword123!@#
DB_NAME=tapsa_sjut_db
JWT_SECRET=GeneratedRandomSecretKeyHere32Chars
CORS_ORIGIN=https://tapsa-sjut.example.com
```

---

## 📚 Additional Resources

- **Node.js Guide**: https://nodejs.org/en/docs/
- **Express Documentation**: https://expressjs.com/
- **MySQL Reference**: https://dev.mysql.com/doc/
- **JWT Authentication**: https://jwt.io/
- **bcryptjs**: https://www.npmjs.com/package/bcryptjs

---

## 📞 Support

For issues or questions:
1. Check the README.md
2. Review error messages carefully
3. Check database connection
4. Verify all environment variables
5. Contact: admin@tapsa-sjut.ac.tz

---

**Installation Complete!** 🎉

Your TAPSA SJUT Platform backend is now ready for use.

Next steps:
1. Explore the API endpoints
2. Integrate with your frontend
3. Customize for your needs
4. Deploy to production

Good luck! 🚀
