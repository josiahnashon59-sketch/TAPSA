// TAPSA SJUT Platform - Backend Server
// Node.js/Express Application

const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// =====================================================
// MIDDLEWARE SETUP
// =====================================================

// Security middleware
app.use(helmet());

// CORS configuration
app.use(cors({
    origin: process.env.CORS_ORIGIN || ['http://localhost:3000', 'http://localhost:5000'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// =====================================================
// DATABASE CONNECTION POOL
// =====================================================

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'tapsa_sjut_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelayMs: 0
});

// Test database connection
pool.getConnection()
    .then(connection => {
        console.log('✓ Database connected successfully');
        connection.release();
    })
    .catch(error => {
        console.error('✗ Database connection failed:', error.message);
        process.exit(1);
    });

// =====================================================
// AUTHENTICATION MIDDLEWARE
// =====================================================

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ 
            success: false, 
            message: 'Access token required' 
        });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key');
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(403).json({ 
            success: false, 
            message: 'Invalid or expired token' 
        });
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }
        next();
    };
};

// =====================================================
// AUTHENTICATION ROUTES
// =====================================================

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
    const { email, password, role } = req.body;

    try {
        // Validate input
        if (!email || !password || !role) {
            return res.status(400).json({
                success: false,
                message: 'Email, password, and role are required'
            });
        }

        const connection = await pool.getConnection();

        // Query user
        const query = 'SELECT * FROM users WHERE email = ? AND role = ?';
        const [users] = await connection.execute(query, [email, role]);

        if (users.length === 0) {
            connection.release();
            return res.status(401).json({
                success: false,
                message: 'Invalid email or role'
            });
        }

        const user = users[0];

        // Verify password (in production, use bcrypt)
        const passwordMatch = await bcrypt.compare(password, user.password_hash);

        if (!passwordMatch) {
            connection.release();
            return res.status(401).json({
                success: false,
                message: 'Invalid password'
            });
        }

        // Check if account is active
        if (user.status !== 'Active') {
            connection.release();
            return res.status(403).json({
                success: false,
                message: `Account is ${user.status.toLowerCase()}`
            });
        }

        // Generate JWT token
        const token = jwt.sign(
            {
                id: user.id,
                email: user.email,
                full_name: user.full_name,
                role: user.role,
                registration_number: user.registration_number
            },
            process.env.JWT_SECRET || 'your_jwt_secret_key',
            { expiresIn: '24h' }
        );

        // Log audit
        const auditQuery = `
            INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address)
            VALUES (?, ?, ?, ?, ?)
        `;
        await connection.execute(auditQuery, [
            user.id,
            'LOGIN',
            'users',
            user.id,
            req.ip
        ]);

        connection.release();

        res.json({
            success: true,
            message: 'Login successful',
            token: token,
            user: {
                id: user.id,
                email: user.email,
                full_name: user.full_name,
                role: user.role,
                registration_number: user.registration_number
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during login'
        });
    }
});

// Logout endpoint (client-side token removal)
app.post('/api/auth/logout', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();

        // Log audit
        const auditQuery = `
            INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address)
            VALUES (?, ?, ?, ?, ?)
        `;
        await connection.execute(auditQuery, [
            req.user.id,
            'LOGOUT',
            'users',
            req.user.id,
            req.ip
        ]);

        connection.release();

        res.json({
            success: true,
            message: 'Logged out successfully'
        });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during logout'
        });
    }
});

// Register endpoint
app.post('/api/auth/register', async (req, res) => {
    const { email, password, full_name, registration_number, phone_number } = req.body;

    try {
        // Validate input
        if (!email || !password || !full_name || !registration_number) {
            return res.status(400).json({
                success: false,
                message: 'All required fields must be provided'
            });
        }

        const connection = await pool.getConnection();

        // Check if user exists
        const checkQuery = 'SELECT id FROM users WHERE email = ? OR registration_number = ?';
        const [existingUsers] = await connection.execute(checkQuery, [email, registration_number]);

        if (existingUsers.length > 0) {
            connection.release();
            return res.status(409).json({
                success: false,
                message: 'User with this email or registration number already exists'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        const insertQuery = `
            INSERT INTO users (email, password_hash, full_name, registration_number, phone_number, role, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        const [result] = await connection.execute(insertQuery, [
            email,
            hashedPassword,
            full_name,
            registration_number,
            phone_number,
            'Member',
            'Pending'
        ]);

        connection.release();

        res.status(201).json({
            success: true,
            message: 'Registration successful. Account pending approval.',
            userId: result.insertId
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during registration'
        });
    }
});

// =====================================================
// USER ROUTES
// =====================================================

// Get user profile
app.get('/api/users/profile', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();

        const query = `
            SELECT id, email, full_name, registration_number, phone_number, 
                   gender, programme, year_of_study, status, membership_status, 
                   role, created_at
            FROM users 
            WHERE id = ?
        `;
        const [users] = await connection.execute(query, [req.user.id]);

        connection.release();

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            user: users[0]
        });

    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Update user profile
app.put('/api/users/profile', authenticateToken, async (req, res) => {
    const { full_name, phone_number, gender, programme, year_of_study } = req.body;

    try {
        const connection = await pool.getConnection();

        const query = `
            UPDATE users 
            SET full_name = ?, phone_number = ?, gender = ?, programme = ?, year_of_study = ?
            WHERE id = ?
        `;
        await connection.execute(query, [
            full_name,
            phone_number,
            gender,
            programme,
            year_of_study,
            req.user.id
        ]);

        connection.release();

        res.json({
            success: true,
            message: 'Profile updated successfully'
        });

    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Get all members (Leaders/Admin only)
app.get('/api/users/members', authenticateToken, authorize('Leader', 'Admin'), async (req, res) => {
    try {
        const connection = await pool.getConnection();

        const query = `
            SELECT id, email, full_name, registration_number, status, membership_status, role
            FROM users 
            WHERE role = 'Member'
            LIMIT 100
        `;
        const [members] = await connection.execute(query);

        connection.release();

        res.json({
            success: true,
            members: members,
            total: members.length
        });

    } catch (error) {
        console.error('Members fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// =====================================================
// ANNOUNCEMENTS ROUTES
// =====================================================

// Get announcements
app.get('/api/announcements', async (req, res) => {
    try {
        const connection = await pool.getConnection();

        const query = `
            SELECT a.*, u.full_name as posted_by_name
            FROM announcements a
            LEFT JOIN users u ON a.posted_by = u.id
            WHERE a.is_published = TRUE
            ORDER BY a.created_at DESC
            LIMIT 50
        `;
        const [announcements] = await connection.execute(query);

        connection.release();

        res.json({
            success: true,
            announcements: announcements
        });

    } catch (error) {
        console.error('Announcements fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Create announcement (Leaders/Admin only)
app.post('/api/announcements', authenticateToken, authorize('Leader', 'Admin'), async (req, res) => {
    const { title, content, deadline, priority } = req.body;

    try {
        if (!title || !content) {
            return res.status(400).json({
                success: false,
                message: 'Title and content are required'
            });
        }

        const connection = await pool.getConnection();

        const query = `
            INSERT INTO announcements (title, content, posted_by, deadline, priority, is_published)
            VALUES (?, ?, ?, ?, ?, TRUE)
        `;
        const [result] = await connection.execute(query, [
            title,
            content,
            req.user.id,
            deadline || null,
            priority || 'Medium'
        ]);

        connection.release();

        res.status(201).json({
            success: true,
            message: 'Announcement created successfully',
            announcement_id: result.insertId
        });

    } catch (error) {
        console.error('Announcement create error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// =====================================================
// EVENTS ROUTES
// =====================================================

// Get events
app.get('/api/events', async (req, res) => {
    try {
        const connection = await pool.getConnection();

        const query = `
            SELECT e.*, u.full_name as created_by_name,
                   COUNT(DISTINCT er.id) as registration_count,
                   COUNT(DISTINCT ea.id) as attendance_count
            FROM events e
            LEFT JOIN users u ON e.created_by = u.id
            LEFT JOIN event_registrations er ON e.id = er.event_id
            LEFT JOIN event_attendance ea ON e.id = ea.event_id
            ORDER BY e.event_date DESC
            GROUP BY e.id
            LIMIT 100
        `;
        const [events] = await connection.execute(query);

        connection.release();

        res.json({
            success: true,
            events: events
        });

    } catch (error) {
        console.error('Events fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Register for event
app.post('/api/events/:eventId/register', authenticateToken, async (req, res) => {
    const { eventId } = req.params;

    try {
        const connection = await pool.getConnection();

        // Check if already registered
        const checkQuery = 'SELECT id FROM event_registrations WHERE event_id = ? AND user_id = ?';
        const [existing] = await connection.execute(checkQuery, [eventId, req.user.id]);

        if (existing.length > 0) {
            connection.release();
            return res.status(409).json({
                success: false,
                message: 'Already registered for this event'
            });
        }

        // Register for event
        const insertQuery = 'INSERT INTO event_registrations (event_id, user_id) VALUES (?, ?)';
        await connection.execute(insertQuery, [eventId, req.user.id]);

        connection.release();

        res.status(201).json({
            success: true,
            message: 'Registered for event successfully'
        });

    } catch (error) {
        console.error('Event registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// =====================================================
// ELECTIONS ROUTES
// =====================================================

// Get elections
app.get('/api/elections', async (req, res) => {
    try {
        const connection = await pool.getConnection();

        const query = `
            SELECT e.*, u.full_name as created_by_name,
                   COUNT(DISTINCT c.id) as candidate_count,
                   COUNT(DISTINCT v.id) as total_votes
            FROM elections e
            LEFT JOIN users u ON e.created_by = u.id
            LEFT JOIN candidates c ON e.id = c.election_id AND c.status = 'Approved'
            LEFT JOIN votes v ON e.id = v.election_id
            GROUP BY e.id
            ORDER BY e.voting_start_date DESC
            LIMIT 50
        `;
        const [elections] = await connection.execute(query);

        connection.release();

        res.json({
            success: true,
            elections: elections
        });

    } catch (error) {
        console.error('Elections fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Cast vote
app.post('/api/elections/:electionId/vote', authenticateToken, async (req, res) => {
    const { electionId } = req.params;
    const { candidateId } = req.body;

    try {
        if (!candidateId) {
            return res.status(400).json({
                success: false,
                message: 'Candidate ID is required'
            });
        }

        const connection = await pool.getConnection();

        // Check if already voted
        const checkQuery = 'SELECT id FROM votes WHERE election_id = ? AND voter_id = ?';
        const [existing] = await connection.execute(checkQuery, [electionId, req.user.id]);

        if (existing.length > 0) {
            connection.release();
            return res.status(409).json({
                success: false,
                message: 'You have already voted in this election'
            });
        }

        // Record vote
        const insertQuery = `
            INSERT INTO votes (election_id, candidate_id, voter_id, ip_address)
            VALUES (?, ?, ?, ?)
        `;
        await connection.execute(insertQuery, [
            electionId,
            candidateId,
            req.user.id,
            req.ip
        ]);

        // Update candidate vote count
        const updateQuery = 'UPDATE candidates SET vote_count = vote_count + 1 WHERE id = ?';
        await connection.execute(updateQuery, [candidateId]);

        connection.release();

        res.status(201).json({
            success: true,
            message: 'Vote recorded successfully'
        });

    } catch (error) {
        console.error('Vote error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// =====================================================
// DASHBOARD/ANALYTICS ROUTES
// =====================================================

// Get dashboard stats
app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();

        // Total members
        const [members] = await connection.execute('SELECT COUNT(*) as count FROM users WHERE role = "Member"');
        
        // Active members
        const [activeMembers] = await connection.execute('SELECT COUNT(*) as count FROM users WHERE role = "Member" AND status = "Active"');
        
        // Pending fees
        const [pendingFees] = await connection.execute('SELECT COUNT(*) as count FROM membership_fees WHERE status = "Pending"');
        
        // Upcoming events
        const [upcomingEvents] = await connection.execute('SELECT COUNT(*) as count FROM events WHERE event_date > NOW()');

        connection.release();

        res.json({
            success: true,
            stats: {
                total_members: members[0].count,
                active_members: activeMembers[0].count,
                pending_fees: pendingFees[0].count,
                upcoming_events: upcomingEvents[0].count
            }
        });

    } catch (error) {
        console.error('Dashboard stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// =====================================================
// HEALTH CHECK
// =====================================================

app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'TAPSA SJUT API is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// =====================================================
// ERROR HANDLING
// =====================================================

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route not found',
        path: req.path
    });
});

// Global error handler
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    
    res.status(error.status || 500).json({
        success: false,
        message: error.message || 'Internal server error',
        error: process.env.NODE_ENV === 'development' ? error : {}
    });
});

// =====================================================
// SERVER STARTUP
// =====================================================

app.listen(PORT, () => {
    console.log('');
    console.log('╔════════════════════════════════════════════╗');
    console.log('║   TAPSA SJUT Platform - Backend Server     ║');
    console.log('╠════════════════════════════════════════════╣');
    console.log(`║ Server running on port: ${PORT}`);
    console.log(`║ Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`║ Database: ${process.env.DB_NAME}`);
    console.log('╚════════════════════════════════════════════╝');
    console.log('');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
    console.log('SIGTERM signal received: closing HTTP server');
    await pool.end();
    process.exit(0);
});

module.exports = app;
