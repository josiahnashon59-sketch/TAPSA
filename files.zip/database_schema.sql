-- TAPSA SJUT Platform - Complete Database Schema
-- MySQL 8.0 Compatible

-- Drop existing database if needed
-- DROP DATABASE IF EXISTS tapsa_sjut_db;
-- CREATE DATABASE tapsa_sjut_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE tapsa_sjut_db;

-- =====================================================
-- 1. USERS TABLE (Core Authentication)
-- =====================================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    registration_number VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    passport_photo LONGBLOB,
    gender ENUM('Male', 'Female', 'Other'),
    programme VARCHAR(100),
    year_of_study INT,
    status ENUM('Active', 'Inactive', 'Suspended', 'Pending') DEFAULT 'Pending',
    membership_status ENUM('Paid', 'Unpaid', 'Overdue', 'Exempt') DEFAULT 'Unpaid',
    fee_status DECIMAL(10, 2) DEFAULT 0.00,
    attendance_rate DECIMAL(5, 2),
    role ENUM('Member', 'Leader', 'Admin', 'Guest') DEFAULT 'Member',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    INDEX idx_email (email),
    INDEX idx_registration (registration_number),
    INDEX idx_role (role),
    INDEX idx_status (status)
);

-- =====================================================
-- 2. ROLES & PERMISSIONS TABLE
-- =====================================================
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    position_level INT,
    department VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    permission_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_role_permission (role_id, permission_id)
);

-- =====================================================
-- 3. LEADERSHIP & POSITIONS TABLE
-- =====================================================
CREATE TABLE leadership_positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    position_title VARCHAR(100) NOT NULL,
    office_hours VARCHAR(200),
    term_start_date DATE,
    term_end_date DATE,
    manifesto LONGTEXT,
    contact_email VARCHAR(100),
    responsibilities TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_position (position_title),
    INDEX idx_user (user_id)
);

-- =====================================================
-- 4. MEMBERSHIP & FEES TABLE
-- =====================================================
CREATE TABLE membership_fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    fee_type ENUM('Membership', 'Graduation', 'Trip', 'Dinner', 'Emergency', 'Other') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    due_date DATE,
    payment_date DATE,
    status ENUM('Pending', 'Paid', 'Overdue', 'Cancelled') DEFAULT 'Pending',
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    receipt_url VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_fee (user_id),
    INDEX idx_status (status),
    INDEX idx_payment_date (payment_date)
);

-- =====================================================
-- 5. ANNOUNCEMENTS & COMMUNICATIONS TABLE
-- =====================================================
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT NOT NULL,
    posted_by INT NOT NULL,
    image_url VARCHAR(255),
    attachment_url VARCHAR(255),
    deadline DATE,
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    target_audience ENUM('All', 'Members', 'Leaders', 'Specific') DEFAULT 'All',
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id),
    INDEX idx_published (is_published),
    INDEX idx_created_at (created_at)
);

-- =====================================================
-- 6. EVENTS & ATTENDANCE TABLE
-- =====================================================
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    description LONGTEXT,
    event_type ENUM('Orientation', 'White Coat', 'General Meeting', 'Health Camp', 'Sports', 'Graduation', 'Community Outreach', 'Seminar', 'Workshop', 'Other') NOT NULL,
    venue VARCHAR(255),
    google_maps_link VARCHAR(500),
    event_date DATETIME NOT NULL,
    end_time DATETIME,
    speakers TEXT,
    capacity INT,
    registration_required BOOLEAN DEFAULT TRUE,
    featured_image VARCHAR(255),
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_event_date (event_date),
    INDEX idx_event_type (event_type)
);

CREATE TABLE event_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Registered', 'Confirmed', 'Cancelled') DEFAULT 'Registered',
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_event_user (event_id, user_id),
    INDEX idx_user (user_id)
);

CREATE TABLE event_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    attendance_status ENUM('Present', 'Late', 'Absent', 'Excused') DEFAULT 'Absent',
    check_in_time DATETIME,
    check_out_time DATETIME,
    qr_scan_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_event_attendance (event_id, user_id),
    INDEX idx_attendance_status (attendance_status)
);

-- =====================================================
-- 7. ACADEMIC RESOURCES TABLE
-- =====================================================
CREATE TABLE academic_resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resource_name VARCHAR(255) NOT NULL,
    resource_type ENUM('Lecture Notes', 'Past Papers', 'Practical Manual', 'Timetable', 'Research Paper', 'Book', 'Video', 'Other') NOT NULL,
    course_code VARCHAR(20),
    course_name VARCHAR(255),
    year_of_study INT,
    semester INT,
    file_url VARCHAR(255) NOT NULL,
    file_size INT,
    uploaded_by INT NOT NULL,
    description LONGTEXT,
    download_count INT DEFAULT 0,
    is_approved BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id),
    INDEX idx_resource_type (resource_type),
    INDEX idx_course (course_code),
    INDEX idx_year (year_of_study)
);

CREATE TABLE resource_downloads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT NOT NULL,
    user_id INT NOT NULL,
    download_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resource_id) REFERENCES academic_resources(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- 8. DIGITAL ELECTIONS TABLE
-- =====================================================
CREATE TABLE elections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    election_name VARCHAR(255) NOT NULL,
    description LONGTEXT,
    nomination_start_date DATETIME,
    nomination_end_date DATETIME,
    voting_start_date DATETIME NOT NULL,
    voting_end_date DATETIME NOT NULL,
    status ENUM('Planning', 'Nomination', 'Approved', 'Ongoing', 'Closed', 'Archived') DEFAULT 'Planning',
    total_voters INT,
    votes_cast INT DEFAULT 0,
    turnout_percentage DECIMAL(5, 2),
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_status (status),
    INDEX idx_voting_dates (voting_start_date, voting_end_date)
);

CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    user_id INT NOT NULL,
    position_applying_for VARCHAR(100) NOT NULL,
    manifesto LONGTEXT,
    biography TEXT,
    photo_url VARCHAR(255),
    campaign_video_url VARCHAR(255),
    nomination_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending', 'Approved', 'Rejected', 'Withdrawn') DEFAULT 'Pending',
    vote_count INT DEFAULT 0,
    approval_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (election_id) REFERENCES elections(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_candidate (election_id, user_id),
    INDEX idx_position (position_applying_for)
);

CREATE TABLE votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    candidate_id INT NOT NULL,
    voter_id INT NOT NULL,
    vote_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    encryption_key VARCHAR(255),
    ip_address VARCHAR(45),
    verified BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (election_id) REFERENCES elections(id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
    FOREIGN KEY (voter_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_vote (election_id, voter_id),
    INDEX idx_vote_time (vote_timestamp)
);

-- =====================================================
-- 9. COMMITTEES TABLE
-- =====================================================
CREATE TABLE committees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    committee_name VARCHAR(100) NOT NULL,
    description LONGTEXT,
    chairperson_id INT,
    vice_chairperson_id INT,
    established_date DATE,
    status ENUM('Active', 'Inactive', 'Archived') DEFAULT 'Active',
    meeting_frequency VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chairperson_id) REFERENCES users(id),
    FOREIGN KEY (vice_chairperson_id) REFERENCES users(id),
    INDEX idx_status (status)
);

CREATE TABLE committee_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    committee_id INT NOT NULL,
    user_id INT NOT NULL,
    position_in_committee VARCHAR(100),
    join_date DATE,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    FOREIGN KEY (committee_id) REFERENCES committees(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_member (committee_id, user_id)
);

CREATE TABLE committee_meetings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    committee_id INT NOT NULL,
    meeting_date DATETIME NOT NULL,
    venue VARCHAR(255),
    agenda LONGTEXT,
    minutes LONGTEXT,
    attendees TEXT,
    status ENUM('Scheduled', 'Held', 'Cancelled') DEFAULT 'Scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (committee_id) REFERENCES committees(id) ON DELETE CASCADE
);

-- =====================================================
-- 10. DOCUMENTS & CERTIFICATES TABLE
-- =====================================================
CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_name VARCHAR(255) NOT NULL,
    document_type ENUM('Meeting Minutes', 'Executive Report', 'Financial Audit', 'Constitution', 'Strategic Plan', 'Policy', 'Other') NOT NULL,
    file_url VARCHAR(255) NOT NULL,
    uploaded_by INT NOT NULL,
    description LONGTEXT,
    is_confidential BOOLEAN DEFAULT FALSE,
    approval_status ENUM('Draft', 'Pending Approval', 'Approved', 'Rejected') DEFAULT 'Draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id),
    INDEX idx_document_type (document_type)
);

CREATE TABLE certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    certificate_type ENUM('Volunteering', 'Event Attendance', 'Leadership Service', 'Special Appreciation', 'Award', 'Other') NOT NULL,
    event_id INT,
    achievement_description TEXT,
    issued_date DATE DEFAULT CURRENT_DATE,
    certificate_number VARCHAR(100) UNIQUE,
    pdf_url VARCHAR(255),
    issued_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id),
    FOREIGN KEY (issued_by) REFERENCES users(id),
    INDEX idx_user (user_id),
    INDEX idx_type (certificate_type)
);

-- =====================================================
-- 11. GALLERY TABLE
-- =====================================================
CREATE TABLE galleries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    album_name VARCHAR(255) NOT NULL,
    description LONGTEXT,
    cover_image VARCHAR(255),
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE gallery_media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gallery_id INT NOT NULL,
    media_type ENUM('Image', 'Video') NOT NULL,
    media_url VARCHAR(255) NOT NULL,
    caption TEXT,
    uploaded_by INT NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (gallery_id) REFERENCES galleries(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

-- =====================================================
-- 12. POLLS & FEEDBACK TABLE
-- =====================================================
CREATE TABLE polls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_title VARCHAR(255) NOT NULL,
    description LONGTEXT,
    poll_type ENUM('Single Choice', 'Multiple Choice', 'Rating', 'Open Feedback') NOT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deadline DATETIME,
    is_active BOOLEAN DEFAULT TRUE,
    results_visible BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_active (is_active)
);

CREATE TABLE poll_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    option_text VARCHAR(255) NOT NULL,
    vote_count INT DEFAULT 0,
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE
);

CREATE TABLE poll_responses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    user_id INT NOT NULL,
    selected_option_id INT,
    response_text LONGTEXT,
    response_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (selected_option_id) REFERENCES poll_options(id),
    UNIQUE KEY unique_poll_user (poll_id, user_id)
);

CREATE TABLE feedback_suggestions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    feedback_title VARCHAR(255) NOT NULL,
    feedback_content LONGTEXT NOT NULL,
    category VARCHAR(100),
    is_anonymous BOOLEAN DEFAULT FALSE,
    status ENUM('Pending', 'Resolved', 'Rejected', 'In Progress') DEFAULT 'Pending',
    response TEXT,
    responded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (responded_by) REFERENCES users(id),
    INDEX idx_status (status)
);

-- =====================================================
-- 13. DIGITAL MEMBERSHIP CARDS TABLE
-- =====================================================
CREATE TABLE membership_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    membership_number VARCHAR(50) UNIQUE NOT NULL,
    qr_code VARCHAR(500),
    card_photo VARCHAR(255),
    validity_start_date DATE,
    validity_end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- 14. PUSH NOTIFICATIONS TABLE
-- =====================================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message LONGTEXT NOT NULL,
    notification_type ENUM('Meeting', 'Election', 'Result', 'Note Upload', 'Fee Deadline', 'Event', 'Announcement', 'Other') NOT NULL,
    related_entity_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_unread (is_read),
    INDEX idx_user (user_id)
);

-- =====================================================
-- 15. AUDIT LOG TABLE
-- =====================================================
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255) NOT NULL,
    entity_type VARCHAR(100),
    entity_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_action (action),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created_at (created_at)
);

-- =====================================================
-- 16. SETTINGS & CONFIGURATION TABLE
-- =====================================================
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value LONGTEXT,
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =====================================================
-- SAMPLE DATA INSERTION
-- =====================================================

-- Insert Roles
INSERT INTO roles (role_name, description, position_level, department) VALUES
('Chairperson', 'Executive Leadership', 1, 'Executive'),
('Vice Chairperson', 'Executive Leadership', 2, 'Executive'),
('Secretary', 'Administrative', 3, 'Administration'),
('Treasurer', 'Finance Management', 4, 'Finance'),
('Academic Officer', 'Academic Affairs', 5, 'Academic'),
('Member', 'Regular Member', 9, 'General'),
('Guest', 'Guest User', 10, 'Guest');

-- Insert Permissions
INSERT INTO permissions (permission_name, description) VALUES
('manage_users', 'Create, read, update, delete users'),
('manage_announcements', 'Create and manage announcements'),
('manage_elections', 'Manage election process'),
('view_financials', 'View financial reports'),
('manage_events', 'Create and manage events'),
('upload_resources', 'Upload academic resources'),
('approve_members', 'Approve member registrations'),
('view_reports', 'View analytics and reports');

-- Insert Sample Users
INSERT INTO users (registration_number, email, phone_number, password_hash, full_name, gender, programme, year_of_study, status, role) VALUES
('REG001', 'admin@tapsa.com', '255754123456', '$2b$10$hash_here_admin', 'Admin User', 'Male', 'Pharmacy', 3, 'Active', 'Admin'),
('REG002', 'leader@tapsa.com', '255754123457', '$2b$10$hash_here_leader', 'Leader User', 'Female', 'Pharmacy', 4, 'Active', 'Leader'),
('REG003', 'member@tapsa.com', '255754123458', '$2b$10$hash_here_member', 'Member User', 'Male', 'Pharmacy', 2, 'Active', 'Member'),
('REG004', 'john.doe@sjut.ac.tz', '255754123459', '$2b$10$hash_here_john', 'John Doe', 'Male', 'Pharmacy', 2, 'Active', 'Member'),
('REG005', 'jane.smith@sjut.ac.tz', '255754123460', '$2b$10$hash_here_jane', 'Jane Smith', 'Female', 'Pharmacy', 3, 'Active', 'Member');

-- Insert Committees
INSERT INTO committees (committee_name, description, established_date, status) VALUES
('Academic Committee', 'Manages academic affairs and resources', '2023-01-15', 'Active'),
('Finance Committee', 'Manages financial matters', '2023-01-15', 'Active'),
('Sports Committee', 'Organizes sports activities', '2023-01-15', 'Active'),
('Health Committee', 'Health and wellness initiatives', '2023-01-15', 'Active'),
('Entertainment Committee', 'Organizes social events', '2023-01-15', 'Active');

-- Insert System Settings
INSERT INTO system_settings (setting_key, setting_value, description, is_public) VALUES
('membership_fee', '50000', 'Annual membership fee in TZS', FALSE),
('platform_name', 'TAPSA SJUT Platform', 'Official platform name', TRUE),
('contact_email', 'admin@tapsa.sjut.ac.tz', 'Administrative contact email', TRUE),
('graduation_fee', '150000', 'Graduation ceremony fee in TZS', FALSE),
('emergency_contact', 'emergency@tapsa.sjut.ac.tz', 'Emergency contact email', FALSE);

-- Create Indexes for better performance
CREATE INDEX idx_user_role ON users(role);
CREATE INDEX idx_user_status ON users(status);
CREATE INDEX idx_event_created ON events(created_at);
CREATE INDEX idx_announcement_published ON announcements(is_published);
CREATE INDEX idx_election_status ON elections(status);
CREATE INDEX idx_fee_user_date ON membership_fees(user_id, payment_date);

-- End of database schema
