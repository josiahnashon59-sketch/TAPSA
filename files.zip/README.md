# TAPSA SJUT Platform - Complete Backend & Database Setup

## 📋 Project Overview

TAPSA SJUT Platform is a comprehensive digital ecosystem designed to streamline administrative operations, enhance student engagement, and provide robust academic and governance support for the Tanzania Pharmaceutical Students' Association at St. John's University of Tanzania.

## 🎯 Key Features

- **Member Management** - Streamlined onboarding, profiles, fee tracking, digital identification
- **Digital Elections** - Secure, transparent voting system with real-time results
- **Academic Resources** - Centralized access to lecture notes, past papers, practical manuals
- **Event Management** - QR-code based attendance tracking, event registration
- **Financial Management** - Fee tracking, payment receipts, financial reporting
- **Leadership Dashboard** - Analytics, member statistics, election management
- **Communication Hub** - Real-time announcements, push notifications, feedback system
- **Role-Based Access Control** - Secure permission management for different user types

## 📁 Project Structure

```
tapsa-sjut-platform/
├── server.js                 # Express application entry point
├── package.json              # Node.js dependencies
├── .env.example              # Environment configuration template
├── database_schema.sql       # Complete MySQL database schema
├── login.html                # Frontend login page
├── README.md                 # This file
├── config/
│   └── database.js           # Database connection configuration
├── middleware/
│   ├── auth.js               # JWT authentication middleware
│   ├── errorHandler.js       # Error handling middleware
│   └── validation.js         # Input validation middleware
├── routes/
│   ├── auth.js               # Authentication routes
│   ├── users.js              # User management routes
│   ├── announcements.js      # Announcement routes
│   ├── events.js             # Event management routes
│   ├── elections.js          # Election routes
│   └── dashboard.js          # Analytics routes
├── controllers/
│   ├── authController.js     # Authentication logic
│   ├── userController.js     # User operations
│   ├── electionController.js # Election operations
│   └── eventController.js    # Event operations
├── models/
│   └── queries.js            # Database queries
├── uploads/                  # File upload directory
├── logs/                     # Application logs
└── public/                   # Static files
```

## 🚀 Quick Start Guide

### Prerequisites

- **Node.js** (v16 or higher)
- **MySQL** (v8.0 or higher)
- **npm** (v8 or higher)
- Basic knowledge of JavaScript and SQL

### Step 1: Clone/Setup Project

```bash
# Create project directory
mkdir tapsa-sjut-platform
cd tapsa-sjut-platform

# Copy all files to this directory
# Files: server.js, package.json, .env.example, database_schema.sql, login.html
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Setup Database

```bash
# Login to MySQL
mysql -u root -p

# Create database and run schema
CREATE DATABASE tapsa_sjut_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tapsa_sjut_db;
SOURCE database_schema.sql;

# Exit MySQL
EXIT;
```

### Step 4: Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your settings
nano .env  # or use your preferred editor
```

Update these critical values in `.env`:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=tapsa_sjut_db
JWT_SECRET=your_secret_key_here
```

### Step 5: Start Server

```bash
# Development mode (with auto-reload)
npm run dev

# Production mode
npm start
```

Server will start at: `http://localhost:5000`

## 🔐 Default Test Credentials

The database comes with sample users for testing:

| Email | Password | Role |
|-------|----------|------|
| admin@tapsa.com | Demo@123 | Admin |
| leader@tapsa.com | Demo@123 | Leader |
| member@tapsa.com | Demo@123 | Member |

**⚠️ Change these credentials in production!**

## 📖 API Documentation

### Authentication Endpoints

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@tapsa.com",
  "password": "Demo@123",
  "role": "Admin"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "email": "admin@tapsa.com",
    "full_name": "Admin User",
    "role": "Admin"
  }
}
```

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "student@sjut.ac.tz",
  "password": "SecurePass123",
  "full_name": "John Doe",
  "registration_number": "REG001234",
  "phone_number": "+255700123456"
}

Response:
{
  "success": true,
  "message": "Registration successful",
  "userId": 5
}
```

#### Logout
```http
POST /api/auth/logout
Authorization: Bearer {token}

Response:
{
  "success": true,
  "message": "Logged out successfully"
}
```

### User Endpoints

#### Get User Profile
```http
GET /api/users/profile
Authorization: Bearer {token}

Response:
{
  "success": true,
  "user": {
    "id": 1,
    "email": "admin@tapsa.com",
    "full_name": "Admin User",
    "registration_number": "REG001",
    "status": "Active",
    "role": "Admin"
  }
}
```

#### Update Profile
```http
PUT /api/users/profile
Authorization: Bearer {token}
Content-Type: application/json

{
  "full_name": "Updated Name",
  "phone_number": "+255700000000",
  "gender": "Male",
  "programme": "Pharmacy"
}

Response:
{
  "success": true,
  "message": "Profile updated successfully"
}
```

#### Get Members List
```http
GET /api/users/members
Authorization: Bearer {token}
(Requires Leader or Admin role)

Response:
{
  "success": true,
  "members": [...],
  "total": 150
}
```

### Announcements Endpoints

#### Get Announcements
```http
GET /api/announcements

Response:
{
  "success": true,
  "announcements": [...]
}
```

#### Create Announcement
```http
POST /api/announcements
Authorization: Bearer {token}
Content-Type: application/json

{
  "title": "Important Meeting",
  "content": "All members are required to attend...",
  "deadline": "2024-02-15",
  "priority": "High"
}

Response:
{
  "success": true,
  "message": "Announcement created successfully",
  "announcement_id": 1
}
```

### Events Endpoints

#### Get Events
```http
GET /api/events

Response:
{
  "success": true,
  "events": [...]
}
```

#### Register for Event
```http
POST /api/events/:eventId/register
Authorization: Bearer {token}

Response:
{
  "success": true,
  "message": "Registered for event successfully"
}
```

### Elections Endpoints

#### Get Elections
```http
GET /api/elections

Response:
{
  "success": true,
  "elections": [...]
}
```

#### Cast Vote
```http
POST /api/elections/:electionId/vote
Authorization: Bearer {token}
Content-Type: application/json

{
  "candidateId": 5
}

Response:
{
  "success": true,
  "message": "Vote recorded successfully"
}
```

### Dashboard Endpoints

#### Get Statistics
```http
GET /api/dashboard/stats
Authorization: Bearer {token}

Response:
{
  "success": true,
  "stats": {
    "total_members": 250,
    "active_members": 200,
    "pending_fees": 30,
    "upcoming_events": 5
  }
}
```

### Health Check
```http
GET /api/health

Response:
{
  "success": true,
  "message": "TAPSA SJUT API is running",
  "version": "1.0.0"
}
```

## 🔐 Security Features

- **JWT Authentication** - Stateless token-based authentication
- **Password Hashing** - bcrypt for secure password storage
- **Rate Limiting** - Protection against brute force attacks
- **CORS** - Cross-Origin Resource Sharing configuration
- **Helmet.js** - HTTP headers security
- **Input Validation** - Comprehensive request validation
- **Audit Logging** - Track all user actions
- **SQL Injection Prevention** - Parameterized queries
- **Role-Based Access Control** - Fine-grained permissions

## 📊 Database Schema

### Core Tables

1. **users** - User accounts and profiles
2. **roles** - User roles and permissions
3. **membership_fees** - Fee tracking and payments
4. **announcements** - System announcements
5. **events** - Event management
6. **event_attendance** - Attendance tracking
7. **elections** - Election management
8. **candidates** - Election candidates
9. **votes** - Voting records
10. **committees** - Committee management
11. **academic_resources** - Educational materials
12. **notifications** - Push notifications
13. **audit_logs** - System audit trail

## 🧪 Testing

### Run Tests
```bash
npm test
```

### Test Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@tapsa.com",
    "password": "Demo@123",
    "role": "Admin"
  }'
```

## 📝 Frontend Integration

### Login Page Setup
1. Place `login.html` in your public directory
2. Update API endpoint in login.html to match your server
3. Include authentication token in all API requests:

```javascript
const token = localStorage.getItem('user_token');

fetch('/api/users/profile', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
```

## 🚢 Deployment

### Production Checklist

- [ ] Change all default passwords
- [ ] Update JWT_SECRET to a strong random string
- [ ] Set NODE_ENV=production
- [ ] Configure proper database backups
- [ ] Set up SSL/HTTPS certificates
- [ ] Configure email SMTP settings
- [ ] Set up monitoring and logging
- [ ] Configure file upload limits
- [ ] Test all API endpoints
- [ ] Set up firewall rules

### Deploy to Heroku

```bash
# Initialize Heroku app
heroku create tapsa-sjut-platform

# Set environment variables
heroku config:set DB_HOST=your_db_host
heroku config:set JWT_SECRET=your_secret

# Deploy
git push heroku main
```

### Deploy to DigitalOcean

```bash
# SSH into your droplet
ssh root@your_server_ip

# Clone repository
git clone your_repo_url
cd tapsa-sjut-platform

# Install dependencies
npm install

# Start with PM2
npm install -g pm2
pm2 start server.js --name "tapsa-sjut-api"
pm2 save
```

## 🔧 Troubleshooting

### Database Connection Error
```
Solution: Check DB credentials in .env file
mysql -h localhost -u root -p -e "SELECT 1"
```

### Port Already in Use
```
Solution: Change PORT in .env or kill process using port 5000
lsof -ti:5000 | xargs kill -9
```

### JWT Token Expired
```
Solution: Generate new token by logging in again
Token expiration set to: 24h (configurable in .env)
```

### File Upload Fails
```
Solution: Create uploads directory and check permissions
mkdir uploads
chmod 755 uploads
```

## 📞 Support & Documentation

- **Documentation**: Check comments in source code
- **API Docs**: Available at `/api/docs`
- **Email Support**: admin@tapsa-sjut.ac.tz
- **GitHub Issues**: Report bugs and request features

## 📜 License

MIT License - See LICENSE file for details

## 👥 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 🎓 Credits

Developed for Tanzania Pharmaceutical Students' Association
St. John's University of Tanzania

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Status**: Production Ready

For latest updates and documentation, visit the project repository.
